MacroRec - keyboard / mouse / camera macro recorder (Windows 64-bit)

1. Unzip and double-click MacroRec.exe. No install, no command line.
2. Press F8 (or the Record button) to start recording, F8 again to stop.
   Press F9 (or the Play button) to replay, F9 again to stop.
   The hotkeys work while your game or app is in front.
3. Settings are in the window:
   Mode   Game = replays camera movement. Desktop = replays exact cursor positions.
   Speed  0.25x to 4x.   Repeat  1 to 99 times, or forever.
   Start delay  seconds to wait so you can switch to your window.
   On mouse bump  what happens if you bump the real mouse during playback:
          Off  = ignore it.   Stop = stop the macro so you can take over.
          Fix  = (default) put the mouse back on the macro's path and keep going.
          Desktop mode snaps the cursor back exactly; Game mode cancels the
          movement (close, but not pixel-perfect). Clicks always stop the macro.
          Press F9 any time to stop it yourself.
4. Open... / Save as... load and save macro files. Your last recording is
   kept automatically and loads next time you start the app.

Tip: use the hotkeys, not the buttons, while recording in a game. Clicking
the Stop button is trimmed out of the recording, but hotkeys are cleaner.

If Windows SmartScreen warns about an unknown publisher, that is because the
file is unsigned. The source is in MacroRec-source.zip if you want to check it.
SECURITY (a popup also shows this the first time you open the app, and every
time you open a macro file): only open macro files you made yourself, or that came from people
you know and trust. A macro file is a list of key presses and clicks that
MacroRec performs on your PC as if you typed them. A file from a stranger
could open programs, type commands or delete files. MacroRec checks that a
file is a valid macro, but it cannot tell whether what the macro does is safe.
